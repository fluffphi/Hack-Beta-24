from socket import *
import struct
import json
import os
import time
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox as message
import _thread
import receiveui


def get_time():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())


def get_local_ip():
    hostname = gethostname()
    ip = gethostbyname(hostname)
    return hostname, ip


def receive():
    receive = receiveui.Receive()
    receive.ui_windows()


class Send:
    def __init__(self):
        self.title = 'File Transfer'
        self.root = tk.Tk()
        self.root.title(self.title)
        self.sw = self.root.winfo_screenwidth()
        self.sh = self.root.winfo_screenheight()
        self.x = (self.sw - 600) / 2
        self.y = (self.sh - 400) / 2
        self.root.geometry('%dx%d+%d+%d' % (600, 400, self.x, self.y))
        self.frame = tk.Frame(self.root)
        self.label = tk.Label(self.frame, text='Local Ip Address：')
        self.str_ip = tk.StringVar()
        self.entry = tk.Entry(self.frame, width=30, textvariable=self.str_ip)
        self.button_get_local_ip = tk.Button(self.frame, text='Getting local Ip address', command=self.action_button_get_local_ip)
        self.button_send = tk.Button(self.frame, text='Sending file', command=self.action_button_send)
        self.str_path = tk.StringVar()
        self.label_file_path = tk.Label(self.frame, text='file location:')
        self.entry_file_path = tk.Entry(self.frame, textvariable=self.str_path, width=30)
        self.button_select = tk.Button(self.frame, text='select', width=10, command=self.action_button_select)
        self.text_show = tk.Text(self.frame, width=45, height=20)
        self.menubar = tk.Menu(self.root)

    def action_button_select(self):
        file_path = filedialog.askopenfilename()
        if file_path != '':
            self.str_path.set(file_path)

    def action_button_get_local_ip(self):
        hostname, ip = get_local_ip()
        self.text_show.insert(1.0, 'local machine name：%s,\nIP address：%s\n' % (hostname, ip))

    def run_button_send(self, id):
        try:
            server = socket(AF_INET, SOCK_STREAM)
            ip = self.entry.get()
            ip_port = (ip, 8888)

            buffsize = 1024

            server.bind(ip_port)
            server.listen(5)
            self.text_show.insert(1.0, get_time()+'waiting to connect...\n')
            while True:
                conn, addr = server.accept()
                self.text_show.insert(1.0, get_time()+'connected:%s\n' % str(addr))
                while True:
                    if not conn:
                        self.text_show.insert(1.0, get_time() + 'disconnect\n')
                        break
                    file = self.str_path.get()
                    filesize_bytes = os.path.getsize(file)  # geting the file size and byte
                    self.text_show.insert(1.0, get_time() + 'size:%s/byte\n' % str(filesize_bytes))
                    filename = time.strftime('%Y%m%d%H%M%S', time.localtime()) + '.' + file.split('/')[-1].split('.')[1]
                    print(filename)
                    dirc = {
                        'filename': filename,
                        'filesize_bytes': filesize_bytes,
                    }
                    # head_info = json.dumps(dirc)
                    head_info = bytes(json.dumps(dirc), encoding='utf-8')
                    head_info_len = struct.pack('i', len(head_info))
                    conn.send(head_info_len)
                    # conn.send(head_info.encode('utf-8'))
                    conn.send(head_info)

                    with open(file, 'rb') as f:
                        data = f.read()
                        conn.sendall(data)
                    self.text_show.insert(1.0, get_time() + 'success！\n')
                    break
                break
        except Exception as e:
            self.text_show.insert(1.0, e.__str__() + '\n')

    def action_button_send(self):
        if self.str_ip.get() == '' or self.str_path.get() == '':
            message.showerror('Error', 'IP address or location cannot be empty!')
        else:
            thread = _thread.start_new_thread(self.run_button_send, (1,))
            print(thread)

    def ui_windows(self):
        self.label.grid(row=0, column=0, pady=8)
        self.entry.grid(row=0, column=1, pady=8)
        self.entry.focus()
        self.label_file_path.grid(row=1, column=0, pady=4)
        self.entry_file_path.grid(row=1, column=1, pady=4)
        self.button_select.grid(row=1, column=2, pady=4)
        self.button_get_local_ip.grid(row=2, column=0, pady=4)
        self.button_send.grid(row=2, column=1, pady=4)
        show_content = 'Note：\n1. File transfer is divided into two modeules "Sender" and Receiver", you are using “Receiver".\n2. Input the other Ip addrress, click "received file" and wait. \n' \
                       '3. Click "open file" to the received filee \n4. received file is store at d:/file_accept \n\n File transfer download method:' \
                       '\nIn Browser enter 192.168.1.54:8080/zf in the pop-up webpage just hit download.\n'
        self.text_show.insert(1.0, show_content)
        self.text_show.grid(row=3, column=0, columnspan=3)
        self.menubar.add_command(label='Open receive', command=receive, foreground='red', background='green')
        self.root.config(menu=self.menubar)
        self.frame.pack()
        self.root.mainloop()


if __name__ == '__main__':
    send = Send()
    send.ui_windows()