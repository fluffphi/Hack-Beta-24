import tkinter as tk
from tkinter import ttk
from socket import *
import struct
import json
import os
import sys
import time
import _thread
import tkinter.messagebox as message


def get_time():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())


def get_local_ip():
    hostname = gethostname()
    ip = gethostbyname(hostname)
    return hostname, ip


class Receive:
    def __init__(self):
        self.title = 'File Transfer'
        self.root = tk.Tk()
        self.root.title(self.title)
        self.sw = self.root.winfo_screenwidth()
        self.sh = self.root.winfo_screenheight()
        self.x = (self.sw - 600) / 2
        self.y = (self.sh - 400) / 2
        self.root.geometry('%dx%d+%d+%d' % (600, 400, self.x, self.y))
        self.frame = tk.Frame(self.root)
        self.button_start_receive = tk.Button(self.frame, text='Receive file', command=self.action_button_start_receive)
        self.text_show = tk.Text(self.frame,
                                 width=42,
                                 height=20)
        self.progressbar = ttk.Progressbar(self.frame, length=200)

        self.entry = tk.Entry(self.frame)
        self.label = tk.Label(self.frame, text='Their IP address：')
        self.button_getip = tk.Button(self.frame, text='Getting host Ip address', command=self.action_button_get_local_ip)
        self.button_open_file = tk.Button(self.frame, text='Open file', command=self.action_button_open_file)
        self.open_file_path = ''
        self.scroll = tk.Scrollbar()

    def action_button_open_file(self):
        if self.open_file_path == '':
            message.showwarning('Error', 'not received any file！')
        else:
            os.startfile(self.open_file_path)

    def action_button_get_local_ip(self):
        hostname, ip = get_local_ip()
        self.text_show.insert(1.0, 'Local Ip：%s,\nIP address：%s\n' % (hostname, ip))

    def run_button_start_receive(self, id):
        ip = self.entry.get()
        if ip == '':
            message.showerror('Error', 'IP address cannot be empty！')
            return
        ip_port = (ip, 8888)
        buffsize = 1024
        self.text_show.insert(1.0, get_time()+'waiting to received...\n')
        while True:
            try:
                client = socket(AF_INET, SOCK_STREAM)
                client.connect_ex(ip_port)

                head_struct = client.recv(4)

                head_len = struct.unpack('i', head_struct)[0]
                data = client.recv(head_len)
                head_dir = json.loads(data.decode('utf-8'))
                filesize_b = head_dir['filesize_bytes']
                filename = head_dir['filename']
                if head_struct:
                    self.text_show.insert(1.0, get_time()+'connect to server, waiting to accept...\n')

                recv_len = 0
                recv_mesg = b''
                old = time.time()
                file_path = 'd:/file_accept'
                if os.path.exists(file_path):
                    f = open(file_path + '/' + filename, 'wb')
                else:
                    os.mkdir(file_path)
                    f = open(file_path + '/' + filename, 'wb')
                self.progressbar['maximum'] = filesize_b
                self.progressbar['value'] = 0

                while recv_len < filesize_b:

                    if filesize_b - recv_len > buffsize:
                        recv_mesg = client.recv(buffsize)
                        f.write(recv_mesg)
                        recv_len += len(recv_mesg)

                    else:
                        recv_mesg = client.recv(filesize_b - recv_len)
                        recv_len += len(recv_mesg)
                        f.write(recv_mesg)
                    self.progressbar['value'] = recv_len
                    self.frame.update()
                now = time.time()
                stamp = int(now - old)
                self.text_show.insert(1.0, filename + '  Total received：%s, size：%s， take：%ds --> sucess！\n' % (str(recv_len),
                                                                                               str(filesize_b), stamp))

                # self.text_show.insert(1.0, 'time %ds\n' % stamp)
                self.open_file_path = (file_path + '/' + filename)
                f.close()
            except Exception as e:
                exc_str = '[WinError 10057] Because the socket was not connected and (when using a sendto call to send a datagram socket) no address was provided,' \
                          'The request to send or receive data was not accepted'
                if e.__str__() != exc_str:
                    self.text_show.insert(1.0, e.__str__()+'\n')
                    print(e)
                else:
                    continue
                time.sleep(2)

    def action_button_start_receive(self):
        thread = _thread.start_new_thread(self.run_button_start_receive, (1,))
        print(thread)

    def ui_windows(self):
        self.label.grid(row=0, column=0,  pady=8)
        self.entry.focus()
        self.entry.grid(row=0, column=1, pady=8)
        # self.button_getip.grid(row=1, column=0, pady=6)
        self.button_start_receive.grid(row=1, column=0, pady=6)
        self.button_open_file.grid(row=1, column=1, pady=6)
        show_content = 'Note：\n1. File transfer is divided into two modeules "Sender" and Receiver", you are using “Receiver".\n2. Input the other Ip addrress, click "received file" and wait. \n' \
                       '3. Click "open file" to the received filee \n4. received file is store at d:/file_accept \n\n File transfer download method:' \
                       '\nIn Browser enter 192.168.1.54:8080/zf in the pop-up webpage just hit download.\n'


        self.text_show.insert(1.0, show_content)
        self.scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.scroll.config(command=self.text_show.yview)
        self.text_show.config(yscrollcommand=self.scroll.set)
        self.text_show.grid(row=2, column=0, columnspan=3, pady=6)
        self.progressbar.grid(row=3, column=0, columnspan=3)

        self.frame.pack()
        self.root.mainloop()


if __name__ == '__main__':
    receive = Receive()
    receive.ui_windows()